define(["qlik"], function (qlik) {
  return {
    support: {
      snapshot: true,
      export: true,
      exportData: false,
    },
    definition: {
      type: "items",
      component: "accordion",
      items: {
        link: {
          type: "string",
          expression: "optional",
          label: "Web link",
          ref: "custom.webLink",
        },
        settings:{
          uses: "settings"
        }
      }
    },
    paint: function ($element, layout) {
      
      function renderIFrame(){
        let html = `<iframe frameborder="0" src="${layout.custom.webLink}" style="height: 100%; width: 100%;"></iframe>`;
        $element.html(html);
        console.log("rendered...");
      }
      //add your rendering code here
      renderIFrame()

      //needed for export
      return qlik.Promise.resolve();
    },
  };
});
